//获取url内的参数
function getParam(name)
	{
	       var query = window.location.search.substring(1);
	     //  console.log(query)
	       query = decodeURI(decodeURI(query));
	       //console.log(query)
	       var vars = query.split("&");
	       for (var i=0;i<vars.length;i++) {
	               var pair = vars[i].split("=");
	               if(pair[0] == name){return pair[1];}
	       }
	       return(false);
	}

function openLayer(url,title,area){
	if(!area){
		area= ["500px","400px"];
	}
	layer.open({
		type : 2,
		title : title,
		shadeClose : false,
		shade : 0.4,
		maxmin : false, //开启最大化最小化按钮
		area :area,
		content :url
  })
}

function closeLayer(){
	var index = parent.layer.getFrameIndex(window.name);
	parent.layer.close(index);
}

function openAlert(title){
	layer.alert(title, {
		  closeBtn: 0
		});
}
function openPrompt(title,val,fn,type,data,btn,fn1)    //0文本  1密码  2多行  3数字  4选项
{
	if(!type)type=0;
	if(!btn)btn=["确认","取消"];
	layer.prompt({title: title, formType: type,value:val,data:data,btn: btn,btn2:fn1}, function(txt, index){
		  layer.close(index);
		 if(fn) fn(txt,index);
		});
}

function openConfirm(title,fn,bts){
	if(!bts)bts=null;
	 layer.confirm(title,bts, function(){
		  layer.closeAll('dialog');
		  if(fn)fn();
	 });
}

function LAY_Table(layid,elem,url,toolbar,cols){
	this.table;
	this.form;
	var layer;
	var $;
	var self=this;
	this.ontool;
	this.ontoolbar;
	this.onload;
	this.init=function(){
		layui.use(["table","jquery","layer","form"],function(){
			self.table=layui.table;
			self.layer=layui.layer;
			self.$=layui.jquery;
			self.form=layui.form;
			//基本实例
			self.table.render({
			    elem: "#"+elem//绑定容器
			    ,height: 'full-10'
			    ,url: url //设置数据接口
			    ,page: false //开启分页
			    ,toolbar:toolbar
			    ,cols:cols
			    , done: function (res, curr, count) {
			    	if(self.onload)self.onload(res);
			    }
			  });
		
			self.table.on('tool('+layid+')',
			        function(obj) {
			 if(self.ontool)self.ontool(obj.event,obj.data,obj.update);
		 });
		
			self.table.on('toolbar('+layid+')',
			        function(obj) {
			 if(self.ontoolbar)self.ontoolbar(obj.event);
		 });
	});
}	
	
	this.setselectevent=function(layid,fn){
		self.form.on('select('+layid+')',
		        function(data) {
		 if(fn)fn(data.value);
	 });
	}
	
	this.list_status= function (el,url,parms,def,ex){
		el=this.$(el);
		el.empty();
		self.$.get(url,parms,function(json){
			var inner="";
			if(ex)inner+=ex;
			for(var i=0;i<json.length;i++){
				var selected="";
				if(typeof(def)!="undefined"&&def==i)  selected="selected='selected'";
				inner+="<option value='"+i+"' "+selected+">"+json[i]+"</option>";
			}
				el.html(inner);
				self.form.render();
		},"json");
	}
	this.list_data= function (el,url,parms,def,namecol,exopt,fn){
		if(!namecol)namecol="name";
		el=this.$(el);
		el.empty();
		var currentid=0;
		self.$.get(url,parms,function(json){
			if(exopt) {
				json.unshift(exopt);
			}
			var inner="";
			for(var i=0;i<json.length;i++){
				var selected="";
				if(typeof(def)!="undefined"&&def==json[i].id) {
					selected="selected='selected'";
					currentid=json[i].id;
				}
				inner+="<option value='"+json[i].id+"' "+selected+">"+json[i][namecol]+"</option>";
			}
			if(currentid==0){
				if(json.length>0) currentid=json[0].id;
			}
			if(fn) fn(currentid);
				el.html(inner);
				self.form.render();
		},"json");
	}
	
	this.fresh=function(obj){
		if(!obj)obj={};
		this.table.reload(elem, {
	        where: obj
	    });
	}
}

function LAY_Form(layid){
	this.form;
	this.laydate;
	this.layer;
	this.$;
	var self=this;
	this.complete;
	this.onsubmit;
	this.init=function(){
		layui.use(["form","jquery","layer","laydate"],function(){
			self.form=layui.form;
			self.layer=layui.layer;
			self.laydate=layui.laydate;
			self.$=layui.jquery;
			self.form.on('submit(save)', function(data) {
				if(self.onsubmit){
					self.onsubmit(data);
				}
			});
			
			
			if(self.complete)self.complete();
			self.form.render();
			
			this.$("input").on("keydown",function(e){
				if(e.keyCode!=13) return;
				var els=self.$("input");
				var index=els.index(self.$(this));
				if(index<els.length-1){
					els[index+1].focus();
				}else{
					self.$('[lay-filter="save"]').click();
				}
			})
		});
		
		
	}
	
	this.val=function(json){
		this.form.val(layid,json);
	}
	
	this.list_status= function (el,url,parms,def){
		el=this.$(el);
		el.empty();
		form.$.get(url,parms,function(json){
			var inner="";
			for(var i=0;i<json.length;i++){
				var selected="";
				if(typeof(def)!="undefined"&&def==i)  selected="selected='selected'";
				inner+="<option value='"+i+"' "+selected+">"+json[i]+"</option>";
			}
				el.html(inner);
				self.form.render();
		},"json");
	}
	this.list_data= function (el,url,parms,def,namecol){
		if(!namecol)namecol="name";
		el=this.$(el);
		el.empty();
		self.$.get(url,parms,function(json){
			var inner="";
			for(var i=0;i<json.length;i++){
				var selected="";
				if(typeof(def)!="undefined"&&def==json[i].id)  selected="selected='selected'";
				inner+="<option value='"+json[i].id+"' "+selected+">"+json[i][namecol]+"</option>";
			}
				el.html(inner);
				self.form.render();
		},"json");
	}
}

