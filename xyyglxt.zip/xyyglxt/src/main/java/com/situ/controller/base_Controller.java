package com.situ.controller;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class base_Controller {

	@RequestMapping("getArray")
	public String[] getArray(String classname,String fieldname) throws Exception{
		Class<?> cls=Class.forName(classname);
		Field f=cls.getDeclaredField(fieldname);
		return (String[]) f.get(null);
	}
	
	@RequestMapping("getInfos")
	public List getInfos(String where) throws Exception{
		Field f=this.getClass().getDeclaredField("mapper");
		f.setAccessible(true);//跳过权限检验
		Object o=f.get(this);//mapper
		Method m=o.getClass().getMethod("select", String.class);
		if(where==null)where="";
		return (List) m.invoke(o, where);
	}
}
