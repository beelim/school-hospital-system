package com.situ.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.Department_Mapper;
import com.situ.mapper.Register_Record_Mapper;
import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.Department;
import com.situ.pojo.Register_Record;
import com.situ.utils.DateUtils;

@RestController
@RequestMapping("/Register_Record")
public class Register_Record_Controller extends base_Controller{
	
	@Autowired
	Register_Record_Mapper mapper;
	
	@Autowired
	Department_Mapper dmapper;
	
	@RequestMapping("index")//  /Register_Record/index
	public ResultInfo index(String name){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" where c.name like '%"+name+"%'";
			info.addParms("name", name);
		}
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("insert")
	public ResultData insert(Register_Record u) {
		u.setDate(DateUtils.getNow());
		u.setSrctype(0);
		u.setStatus(2);
		
		Department dep=dmapper.selectByid(u.getDepartment_id());
		int count=mapper.sum("count(1)", " where department_id="+u.getDepartment_id()+" and date='"+u.getDate()+"' ");
		if(count>=dep.getAllcount()) {
			return new ResultData(-1,"没号了");
		}
		u.setIndex(count+1);
		mapper.insert(u);
		return new ResultData(1,"",u);
	}
	
	@RequestMapping("delete")
	public ResultData delete(int id) {
		mapper.delete(id);
		return new ResultData(1);
	}
	
	@RequestMapping("setstatus")
	public ResultData setstatus(Register_Record u) {
		mapper.updatestatus(u);
		return new ResultData(1,u.getStatusname());
	}
	
}
