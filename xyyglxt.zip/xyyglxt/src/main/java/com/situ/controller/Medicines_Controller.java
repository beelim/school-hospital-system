package com.situ.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.Medicines_Mapper;
import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.Medicines;


@RestController
@RequestMapping("/Medicines")
public class Medicines_Controller extends base_Controller{
	
	@Autowired
	Medicines_Mapper mapper;
	
	@RequestMapping("index")//  /Medicines/index
	public ResultInfo index(Integer medicines_type_id){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(medicines_type_id==null) medicines_type_id=0;
		if(medicines_type_id>0){
			where =" where medicines.medicines_type_id ="+medicines_type_id;
			
		}
		info.addParms("medicines_type_id", medicines_type_id);
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("insert")
	public ResultData insert(Medicines u) {
		mapper.insert(u);
		return new ResultData(1);
	}
	
	@RequestMapping("delete")
	public ResultData delete(int id) {
		mapper.delete(id);
		return new ResultData(1);
	}
	

	@RequestMapping("update")
	public ResultData update(Medicines u) {
		mapper.update(u);
		return new ResultData(1);
	}
	
	
	@RequestMapping("info")
	public Medicines info(int id){
		return mapper.selectByid(id);
	}
	
	
}
