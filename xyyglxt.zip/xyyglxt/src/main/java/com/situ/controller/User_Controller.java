package com.situ.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.User_Mapper;
import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.User;
import com.situ.utils.DateUtils;

@RestController
@RequestMapping("/User")
public class User_Controller extends base_Controller{
	
	@Autowired
	User_Mapper mapper;
	
	@RequestMapping("login")
	public ResultData login(User u,HttpSession session) {
		User curr=mapper.login(u.getName());
		if(curr==null) {
			return new ResultData(-1,"无此用户");//无用户
		}else {
			if(curr.getPass().equals(u.getPass())) {
				session.setMaxInactiveInterval(60*20);//激活时间
				session.setAttribute("user", curr);
				return new ResultData(1);//成功登录
			}else {
				return new ResultData(-2,"密码错误");//密码错误
			}
		}
		
	}

	
	@RequestMapping("index")//  /User/index
	public ResultInfo index(String name){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" where user.name like '%"+name+"%'";
			info.addParms("name", name);
		}
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("insert")
	public ResultData insert(User u) {
		u.setPass("123");
		u.setCreatedate(DateUtils.getNowTime());
		mapper.insert(u);
		return new ResultData(1);
	}
	
	@RequestMapping("delete")
	public ResultData delete(int id) {
		mapper.delete(id);
		return new ResultData(1);
	}
	

	@RequestMapping("update")
	public ResultData update(User u) {
		mapper.update(u);
		return new ResultData(1);
	}
	
	
	@RequestMapping("info")
	public User info(int id){
		return mapper.selectByid(id);
	}
	
	
}
