package com.situ.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.User_Mapper;
import com.situ.mapper.Cure_Record_Mapper;
import com.situ.mapper.Register_Record_Mapper;
import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.User;
import com.situ.pojo.Cure_Record;
import com.situ.pojo.Medicines;
import com.situ.pojo.Register_Record;
import com.situ.utils.DateUtils;

@RestController
@RequestMapping("/Cure_Record")
public class Cure_Record_Controller extends base_Controller{
	
	@Autowired
	Cure_Record_Mapper mapper;
	
	@Autowired
	Register_Record_Mapper rmapper;
	
	@RequestMapping("index")//  医生端显示
	public ResultInfo index(String name,HttpSession s){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" and client.name like '%"+name+"%'";
			info.addParms("name", name);
		}
		String now=DateUtils.getNow();
		User u=(User) s.getAttribute("user");
		List<Register_Record> all=rmapper.select(" where register_record.date='"+now+"' "
				+ "and (register_record.status=3 or register_record.user_id="+u.getId() + where +" )");
		for(int i=0;i<all.size();i++) {
			Register_Record r=all.get(i);
			if(r.getStatus() >3 &&r.getStatus()<6) {
				List<Cure_Record> cures=mapper.select(" where cure_record.register_id="+r.getId());
				if(cures.size()==0) continue;
			r.setCure_info(cures.get(0).getInfo());
			r.setCure_status(cures.get(0).getStatus());
			r.setCure_id(cures.get(0).getId());
			}
		}
		info.setData(all);
		return info;
	}
	
	@RequestMapping("updateinfo")
	public ResultData updateinfo(Cure_Record u) {
		mapper.updateinfo(u);
		return new ResultData(1);
	}
	
	
	
	@RequestMapping("insert")
	public ResultData insert(Cure_Record u,HttpSession s) {
		u.setDate(DateUtils.getNow());
		u.setStatus(0);
		u.setInfo("");
		u.setRegister_id(u.getId());
		User user=(User) s.getAttribute("user");
		u.setUser_id(user.getId());
		mapper.insert(u);
		Register_Record r=new Register_Record();
		r.setId(u.getRegister_id());
		r.setStatus(4);
		r.setUser_id(user.getId());
		rmapper.updateall(r);
		return new ResultData(1);
	}
	
	
	
	
}
