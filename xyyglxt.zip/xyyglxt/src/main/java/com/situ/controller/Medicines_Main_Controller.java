package com.situ.controller;




import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.Cure_Record_Mapper;
import com.situ.mapper.Department_Mapper;
import com.situ.mapper.Medicines_Details_Mapper;
import com.situ.mapper.Medicines_Main_Mapper;
import com.situ.mapper.Medicines_Mapper;
import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.User;
import com.situ.pojo.Cure_Record;
import com.situ.pojo.Medicines;
import com.situ.pojo.Medicines_Details;
import com.situ.pojo.Medicines_Main;
import com.situ.utils.DateUtils;

@RestController
@RequestMapping("/Medicines_Main")
public class Medicines_Main_Controller extends base_Controller{
	
	@Autowired
	Medicines_Main_Mapper mapper;
	
	@Autowired
	Department_Mapper dmapper;
	
	@Autowired
	Medicines_Mapper mmapper;
	
	@Autowired
	Medicines_Details_Mapper mdmapper;
	
	@Autowired
	Cure_Record_Mapper cmapper;
	
	@RequestMapping("index")//  /Medicines_Main/index
	public ResultInfo index(String name){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" where c.name like '%"+name+"%'";
			info.addParms("name", name);
		}
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("setstatus")
	public ResultData setstatus(Medicines_Main m) {
		mapper.updatestatus(m);
		return new ResultData(1);
	}
	
	@RequestMapping("insert")
	public ResultData insert(Medicines_Main m,HttpSession s) {
		User u=(User) s.getAttribute("user");
		String key=m.getClient_id()+"-"+u.getId();
		if(!alldata.containsKey(key)) return new ResultData(-1,"没有开药记录");
		ArrayList<Medicines_Details> list=alldata.get(key);
		m.setDate(DateUtils.getNow());
		m.setExec_id(0);
		m.setStatus(1);
		m.setUser_id(u.getId());
		double amount=0;
		for(int i=0;i<list.size();i++) amount+=list.get(i).getAmount();
		m.setAmount(amount);
		mapper.insert(m);
		Cure_Record c=new Cure_Record();
		c.setId(m.getCure_id());
		c.setStatus(1);;
		cmapper.updatestatus(c);
		for(int i=0;i<list.size();i++) {
			list.get(i).setMain_id(m.getId());
			mdmapper.insert(list.get(i));
		}
		return new ResultData(1);
	}
	
	HashMap<String, ArrayList<Medicines_Details>> alldata=new HashMap<String, ArrayList<Medicines_Details>>();
	

	@RequestMapping("getdetails")
	public ResultInfo getdetails(int main_id) {
		ResultInfo info = new ResultInfo();
		info.setData(mdmapper.select(" where medicines_details.main_id="+main_id));
		return info;
	}
	
	@RequestMapping("gettmp")
	public ResultInfo gettmp(int client_id,HttpSession s) {
		ResultInfo info = new ResultInfo();
		User u=(User) s.getAttribute("user");
		String key=client_id+"-"+u.getId();
		if(alldata.containsKey(key)) {
			info.setData(alldata.get(key));
		}
		else info.setData(new ArrayList<Medicines_Details>());
		return info;
	}
	
	@RequestMapping("adddetails")
	public ResultData adddetails(int client_id,int medicines_id,HttpSession s) {
		Medicines m = mmapper.selectByid(medicines_id);
		User u=(User) s.getAttribute("user");
		String key=client_id+"-"+u.getId();
		ArrayList<Medicines_Details> list=new ArrayList<Medicines_Details>();
		if(alldata.containsKey(key)) {
			list=alldata.get(key);
		}
		//加入本次
		Medicines_Details r=new Medicines_Details();
		boolean ishas=false;
		for(int i=0;i<list.size();i++)if(list.get(i).getMedicines_id()==medicines_id) {
			r=list.get(i);
			r.setCount(r.getCount()+1);
			r.setAmount(r.getPrice()*r.getCount());
			ishas=true;
			break;
		}
		if(!ishas) {
			r.setCount(1);
			r.setPrice(m.getAmount());
			r.setAmount(r.getPrice()*r.getCount());
			r.setMedicines_name(m.getName());
			r.setMedicines_id(m.getId());
			list.add(r);
		}
		alldata.put(key,list);
		return new ResultData(1);
	}
	
	@RequestMapping("deldetails")
	public ResultData deldetails(int client_id,int medicines_id,HttpSession s) {
		User u=(User) s.getAttribute("user");
		String key=client_id+"-"+u.getId();
		ArrayList<Medicines_Details> list=new ArrayList<Medicines_Details>();
		if(alldata.containsKey(key)) {
			list=alldata.get(key);
		}else {
			return new ResultData(-1);
		}
		Medicines_Details r=new Medicines_Details();
		boolean ishas=false;
		for(int i=0;i<list.size();i++)if(list.get(i).getMedicines_id()==medicines_id) {
			r=list.get(i);
			ishas=true;
			break;
		}
		if(ishas) {
			if(r.getCount()==1)
			list.remove(r);
			else r.setCount(r.getCount()-1);
		}
		alldata.put(key,list);
		return new ResultData(1);
	}
	
	
	
}
