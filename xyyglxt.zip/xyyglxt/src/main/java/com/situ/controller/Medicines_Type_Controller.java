package com.situ.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.Medicines_Type_Mapper;

import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.Medicines_Type;

@RestController
@RequestMapping("/Medicines_Type")
public class Medicines_Type_Controller extends base_Controller{
	
	@Autowired
	Medicines_Type_Mapper mapper;
	
	@RequestMapping("index")//  /Medicines_Type/index
	public ResultInfo index(String name){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" where name like '%"+name+"%'";
			info.addParms("name", name);
		}
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("insert")
	public ResultData insert(Medicines_Type u) {
		mapper.insert(u);
		return new ResultData(1);
	}
	
	@RequestMapping("delete")
	public ResultData delete(int id) {
		mapper.delete(id);
		return new ResultData(1);
	}
	

	@RequestMapping("update")
	public ResultData update(Medicines_Type u) {
		mapper.update(u);
		return new ResultData(1);
	}
	
	
	@RequestMapping("info")
	public Medicines_Type info(int id){
		return mapper.selectByid(id);
	}
	
	
}
