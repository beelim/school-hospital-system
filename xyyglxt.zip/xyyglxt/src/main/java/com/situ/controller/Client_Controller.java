package com.situ.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.situ.mapper.Client_Mapper;

import com.situ.pojo.ResultData;
import com.situ.pojo.ResultInfo;
import com.situ.pojo.Client;

@RestController
@RequestMapping("/Client")
public class Client_Controller extends base_Controller{
	
	@Autowired
	Client_Mapper mapper;
	
	@RequestMapping("index")//  /Client/index
	public ResultInfo index(String name){//请求参数
		ResultInfo info= new ResultInfo();
		String where="";
		if(name!=null&&name.length()>0) {
			where =" where name like '%"+name+"%'";
			info.addParms("name", name);
		}
		info.setData(mapper.select(where));
		return info;
	}
	
	@RequestMapping("insert")
	public ResultData insert(Client u) {
		mapper.insert(u);
		return new ResultData(1);
	}
	
	@RequestMapping("delete")
	public ResultData delete(int id) {
		mapper.delete(id);
		return new ResultData(1);
	}
	

	@RequestMapping("update")
	public ResultData update(Client u) {
		mapper.update(u);
		return new ResultData(1);
	}
	
	
	@RequestMapping("info")
	public Client info(int id){
		return mapper.selectByid(id);
	}
	
	
}
