package com.situ.interceptor;

import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@org.springframework.context.annotation.Configuration
public class Configuration implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new Login_Interceptor())
		.excludePathPatterns("/login.html","/js/**","/img/**","/css/**","/layui/**","/User/login");
		WebMvcConfigurer.super.addInterceptors(registry);
	}
}
