package com.situ.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;

public class Login_Interceptor implements HandlerInterceptor {
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
	Object u=request.getSession().getAttribute("user");
	if(u==null) {
		response.sendRedirect("/login.html");
	}else {
		return HandlerInterceptor.super.preHandle(request, response, handler);
	}
	return false;
		
	}
	
	
}
