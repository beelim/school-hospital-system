package com.situ.pojo;

public class Medicines_Details {
	
	private int id;
	private int main_id;
	private int medicines_id;
	private int count;
	private double price;
	private double amount;
	
	
	
	public int getMain_id() {
		return main_id;
	}
	public void setMain_id(int main_id) {
		this.main_id = main_id;
	}
	private String medicines_name;
	public String getMedicines_name() {
		return medicines_name;
	}
	public void setMedicines_name(String medicines_name) {
		this.medicines_name = medicines_name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMedicines_id() {
		return medicines_id;
	}
	public void setMedicines_id(int medicines_id) {
		this.medicines_id = medicines_id;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	
	
}
