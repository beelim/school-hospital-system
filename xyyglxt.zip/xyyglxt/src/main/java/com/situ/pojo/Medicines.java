package com.situ.pojo;

public class Medicines {
	private int id;
	private String name;
	private float amount;
	private int medicines_type_id;
	
	private String medicines_type_name;
	public String getMedicines_type_name() {
		return medicines_type_name;
	}
	public void setMedicines_type_name(String medicines_type_name) {
		this.medicines_type_name = medicines_type_name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public int getMedicines_type_id() {
		return medicines_type_id;
	}
	public void setMedicines_type_id(int medicines_type_id) {
		this.medicines_type_id = medicines_type_id;
	}
}
