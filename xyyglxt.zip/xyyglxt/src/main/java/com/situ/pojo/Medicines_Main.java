package com.situ.pojo;

public class Medicines_Main {
	
	private int id;
	private String date;
	private int client_id;
	private int user_id;
	private int cure_id;
	private int exec_id;
	private double amount;
	private int status;
	
	private String client_name;
	public String getClient_name() {
		return client_name;
	}
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}

	private String user_name;
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	
	private String cure_name;
	public String getCure_name() {
		return cure_name;
	}
	public void setCure_name(String cure_name) {
		this.cure_name = cure_name;
	}
	
	private String exec_name;
	public String getExec_name() {
		return exec_name;
	}
	public void setExec_name(String exec_name) {
		this.exec_name = exec_name;
	}
	
	public static String[] statuss= {"未支付","已支付","已领药"};
	public String getStatusname() {
		return statuss[status];
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getCure_id() {
		return cure_id;
	}
	public void setCure_id(int cure_id) {
		this.cure_id = cure_id;
	}
	public int getExec_id() {
		return exec_id;
	}
	public void setExec_id(int exec_id) {
		this.exec_id = exec_id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}

	
	
	
}
