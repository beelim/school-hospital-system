package com.situ.pojo;

public class Register_Record {
	
	private int id;
	private String date;
	private int client_id;
	private int department_id;
	private int index;
	private int srctype;
	private double amount;
	private int status;
	private int user_id;
	
	private String cure_info;
	public String getCure_info() {
		return cure_info;
	}
	public void setCure_info(String cure_info) {
		this.cure_info = cure_info;
	}
	private int cure_id;
	
	public int getCure_id() {
		return cure_id;
	}
	public void setCure_id(int cure_id) {
		this.cure_id = cure_id;
	}
	private int cure_status;
	public int getCure_status() {
		return cure_status;
	}
	public void setCure_status(int cure_status) {
		this.cure_status = cure_status;
	}
	public static String[] cure_statuss= {"未开药","已开药"};
	public String getCure_statusname() {
		return cure_statuss[cure_status];
	}
	
	private String client_name;
	public String getClient_name() {
		return client_name;
	}
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}

	private String department_name;
	public String getDepartment_name() {
		return department_name;
	}
	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}
	
	public static String[] srctypes= {"本地","网络"};
	public String getSrctypename() {
		return srctypes[srctype];
	}
	
	public static String[] statuss= {"未支付","已支付","未到","已到","就诊中","就诊完成","取消"};
	public String getStatusname() {
		return statuss[status];
	}
	
	
	private String user_name;
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	public int getDepartment_id() {
		return department_id;
	}
	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getSrctype() {
		return srctype;
	}
	public void setSrctype(int srctype) {
		this.srctype = srctype;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
	
}
