package com.situ.pojo;

public class ResultData {
private int status=0;
private String msg="";
private Object data1;
private Object data2;
public ResultData() {
	// TODO Auto-generated constructor stub
}

public ResultData(int status) {
	super();
	this.status = status;
}

public ResultData(int status, String msg) {
	super();
	this.status = status;
	this.msg = msg;
}

public ResultData(int status, String msg, Object data1) {
	super();
	this.status = status;
	this.msg = msg;
	this.data1 = data1;
}

public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}

public Object getData1() {
	return data1;
}

public void setData1(Object data1) {
	this.data1 = data1;
}

public Object getData2() {
	return data2;
}

public void setData2(Object data2) {
	this.data2 = data2;
}


}
