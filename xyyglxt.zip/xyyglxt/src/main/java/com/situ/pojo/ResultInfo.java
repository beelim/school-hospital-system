package com.situ.pojo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.print.DocFlavor.STRING;

public class ResultInfo {
	
public ResultInfo() {
	// TODO Auto-generated constructor stub
}

	
public ResultInfo(List data) {
	super();
	this.data = data;
}

private Map<String, Object> searchitems=new HashMap<String, Object>();

public void addParms(String name,Object val) {
	searchitems.put(name, val);
}


private String msg=""; //错误信息
private String code="0";
private List data; //对象集合
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public List getData() {
	return data;
}
public void setData(List data) {
	this.data = data;
}


public Map<String, Object> getSearchitems() {
	return searchitems;
}


public void setSearchitems(Map<String, Object> searchitems) {
	this.searchitems = searchitems;
}


}
