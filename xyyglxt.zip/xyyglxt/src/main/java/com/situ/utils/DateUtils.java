package com.situ.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	public static String getNowTime() {
		SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
		return f.format(new Date());
	}
	
	public static String getNow() {
		SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");
		return f.format(new Date());
	}
}
