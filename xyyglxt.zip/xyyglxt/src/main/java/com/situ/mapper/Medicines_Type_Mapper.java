package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Medicines_Type;


@Repository
public interface Medicines_Type_Mapper {

	@Select("select * from medicines_type  ${where}")
	public List<Medicines_Type> select(@Param("where") String where);
	
	@Select("select * from medicines_type  where id=#{id}")
	public Medicines_Type selectByid(int id);
	
	@Insert("insert into medicines_type  (name) values(#{name})")
	public void insert(Medicines_Type u);
	
	@Delete("delete from medicines_type  where id=#{id}")
	public void delete(int id);
	
	@Update("update medicines_type  set name=#{name} where id=#{id}")
	public void update(Medicines_Type u);
	
	

	
}
