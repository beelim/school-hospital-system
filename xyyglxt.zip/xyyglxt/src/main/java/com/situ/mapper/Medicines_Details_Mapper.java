package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Medicines_Details;


@Repository
public interface Medicines_Details_Mapper {

	@Select("select medicines_details.*,m.name medicines_name"
			+ " from medicines_details inner join medicines m "
			+" on medicines_details.medicines_id=m.id "
			+" ${where} ")
	public List<Medicines_Details> select(@Param("where") String where);
	
	
	@Insert("insert into medicines_details(main_id,medicines_id,count,price,amount)"
			+ " values(#{main_id},#{medicines_id},#{count},#{price},#{amount})")
	public void insert(Medicines_Details u);
	
	@Delete("delete from medicines_details where id=#{id}")
	public void delete(int id);
	
	
	
}
