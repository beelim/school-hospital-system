package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Register_Record;


@Repository
public interface Register_Record_Mapper {

	@Select("select register_record.*,c.name client_name,d.name department_name,u.name user_name"
			+ " from register_record inner join client c inner join department d inner join user u"
			+" on register_record.department_id=d.id and register_record.user_id=u.id and register_record.client_id=c.id "
			+" ${where} ")
	public List<Register_Record> select(@Param("where") String where);
	
	
	@Insert("insert into register_record (date,client_id,department_id,`index`,srctype,amount,status,user_id)"
			+ " values(#{date},#{client_id},#{department_id},#{index},#{srctype},#{amount},#{status},0)")
	public void insert(Register_Record u);
	
	@Update("update register_record set status=#{status} where id=#{id}")
	public void updatestatus(Register_Record u);
	
	@Update("update register_record set status=#{status},user_id=#{user_id} where id=#{id}")
	public void updateall(Register_Record u);
	
	@Delete("delete from register_record where id=#{id}")
	public void delete(int id);
	
	@Select(" select ${col} from register_record ${where} ")
	public int sum(@Param("col") String col,@Param("where") String where);

	
}
