package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Medicines;

@Repository
public interface Medicines_Mapper {

	@Select("select medicines.*,d.name medicines_type_name"
			+ " from medicines inner join medicines_type d on medicines.medicines_type_id=d.id "
			+" ${where} ")
	public List<Medicines> select(@Param("where") String where);
	
	@Select("select * from medicines where id=#{id}")
	public Medicines selectByid(int id);
	
	@Insert("insert into medicines (name,amount,medicines_type_id)"
			+ " values(#{name},#{amount},#{medicines_type_id})")
	public void insert(Medicines u);
	
	@Delete("delete from medicines where id=#{id}")
	public void delete(int id);
	
	@Update("update medicines set name=#{name},amount=#{amount},medicines_type_id=#{medicines_type_id} where id=#{id}")
	public void update(Medicines u);
	
	
}
