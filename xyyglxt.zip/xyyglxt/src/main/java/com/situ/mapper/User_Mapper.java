package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.User;

@Repository
public interface User_Mapper {

	@Select("select user.*,d.name department_name"
			+ " from user inner join department d on user.department_id=d.id and user.id<>0"
			+" ${where} ")
	public List<User> select(@Param("where") String where);
	
	@Select("select * from user where id=#{id}")
	public User selectByid(int id);
	
	@Insert("insert into user (name,pass,power,department_id,createdate)"
			+ " values(#{name},#{pass},#{power},#{department_id},#{createdate})")
	public void insert(User u);
	
	@Delete("delete from user where id=#{id}")
	public void delete(int id);
	
	@Update("update user set name=#{name},power=#{power},department_id=#{department_id} where id=#{id}")
	public void update(User u);
	
	@Select("select * from user where name=#{name}")
	public User login(@Param("name") String name);

	
}
