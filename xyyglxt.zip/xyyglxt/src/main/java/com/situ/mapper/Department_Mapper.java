package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Department;
import com.situ.pojo.User;

@Repository
public interface Department_Mapper {

	@Select("select * from department ${where}")
	public List<Department> select(@Param("where") String where);
	
	@Select("select * from department where id=#{id}")
	public Department selectByid(int id);
	
	@Insert("insert into department (name,allcount) values(#{name},#{allcount})")
	public void insert(Department u);
	
	@Delete("delete from department where id=#{id}")
	public void delete(int id);
	
	@Update("update department set name=#{name},allcount=#{allcount} where id=#{id}")
	public void update(Department u);
	
	

	
}
