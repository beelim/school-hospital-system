package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Client;

@Repository
public interface Client_Mapper {

	@Select("select * from client ${where}")
	public List<Client> select(@Param("where") String where);
	
	@Select("select * from client where id=#{id}")
	public Client selectByid(int id);
	
	@Insert("insert into client (name,sex,tel,addr) values(#{name},#{sex},#{tel},#{addr})")
	public void insert(Client u);
	
	@Delete("delete from client where id=#{id}")
	public void delete(int id);
	
	@Update("update client set name=#{name},sex=#{sex},tel=#{tel},addr=#{addr} where id=#{id}")
	public void update(Client u);
	
	

	
}
