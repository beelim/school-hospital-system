package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Cure_Record;


@Repository
public interface Cure_Record_Mapper {

	@Select("select cure_record.*,c.name register_name,u.name user_name " + 
			" from cure_record inner join register_record r inner join client c inner join user u " + 
			"on cure_record.register_id=r.id and r.client_id=c.id and cure_record.user_id=u.id "
			+" ${where} ")
	public List<Cure_Record> select(@Param("where") String where);
	
	
	@Insert("insert into cure_record(date,register_id,user_id,info,status)"
			+ " values(#{date},#{register_id},#{user_id},#{info},#{status})")
	public void insert(Cure_Record u);
	
	@Update("update cure_record set status=#{status} where id=#{id}")
	public void updatestatus(Cure_Record u);
	
	@Update("update cure_record set info=#{info} where register_id=#{id}")
	public void updateinfo(Cure_Record u);
	
	
	@Select("select * from cure_record where id=#{id}")
	public Cure_Record selectByid(int id);
	
}
