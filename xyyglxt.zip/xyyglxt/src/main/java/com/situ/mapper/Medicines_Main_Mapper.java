package com.situ.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.situ.pojo.Medicines_Main;


@Repository
public interface Medicines_Main_Mapper {

	@Select("select medicines_main.*,c.name client_name,u.name user_name"
			+ " from medicines_main inner join client c inner join user u"
			+" on medicines_main.user_id=u.id and medicines_main.client_id=c.id "
			+" ${where} ")
	public List<Medicines_Main> select(@Param("where") String where);
	
	 @Options(useGeneratedKeys = true,keyProperty = "id",keyColumn = "id")
	@Insert("insert into medicines_main (date,client_id,user_id,cure_id,exec_id,amount,status)"
			+ " values(#{date},#{client_id},#{user_id},#{cure_id},#{exec_id},#{amount},#{status})")
	public void insert(Medicines_Main u);
	 
	@Insert("update Medicines_Main set status=#{status} where id=#{id}")
	public void updatestatus(Medicines_Main u);
	
	@Delete("delete from medicines_main where id=#{id}")
	public void delete(int id);
	
	@Select(" select ${col} from medicines_main ${where} ")
	public int sum(@Param("col") String col,@Param("where") String where);

	
}
